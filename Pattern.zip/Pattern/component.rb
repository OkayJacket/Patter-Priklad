# Компонент - базовий клас для всіх об'єктів у структурі
class Component
  def operation
    raise NotImplementedError, 'Subclasses must implement this method'
  end
end

# Лист - конкретний об'єкт, що не має дітей
class Leaf < Component
  def operation
    "Leaf"
  end
end

# Складовий - об'єкт, який може мати підкомпоненти
class Composite < Component
  def initialize
    @children = []
  end

  def add(child)
    @children << child
  end

  def remove(child)
    @children.delete(child)
  end

  def operation
    result = "Composite("
    result += @children.map { |child| child.operation }.join("+")
    result += ")"
    result
  end
end

# Приклад використання патерну Composite
leaf1 = Leaf.new
leaf2 = Leaf.new
leaf3 = Leaf.new

composite = Composite.new
composite.add(leaf1)
composite.add(leaf2)

composite2 = Composite.new
composite2.add(leaf3)
composite2.add(composite)

puts "Result: #{composite2.operation}"
